package net.optifine.entity.model.anim;

public interface IExpression
{
    ExpressionType getExpressionType();
}
