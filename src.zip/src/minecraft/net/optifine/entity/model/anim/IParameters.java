package net.optifine.entity.model.anim;

public interface IParameters
{
    ExpressionType[] getParameterTypes(IExpression[] var1);
}
