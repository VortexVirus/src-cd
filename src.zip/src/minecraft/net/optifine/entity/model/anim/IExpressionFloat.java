package net.optifine.entity.model.anim;

public interface IExpressionFloat extends IExpression
{
    float eval();
}
