package net.optifine.entity.model.anim;

public interface IExpressionBool extends IExpression
{
    boolean eval();
}
