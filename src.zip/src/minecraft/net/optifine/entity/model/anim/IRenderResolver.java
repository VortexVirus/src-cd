package net.optifine.entity.model.anim;

public interface IRenderResolver
{
    IExpression getParameter(String var1);
}
