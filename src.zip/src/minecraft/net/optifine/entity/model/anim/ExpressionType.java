package net.optifine.entity.model.anim;

public enum ExpressionType
{
    FLOAT,
    BOOL;
}
