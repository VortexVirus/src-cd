package net.optifine.entity.model.anim;

public interface IExpressionResolver
{
    IExpression getExpression(String var1);
}
