package net.minecraft.tileentity;

public class TileEntityEndPortal extends TileEntity
{
}
