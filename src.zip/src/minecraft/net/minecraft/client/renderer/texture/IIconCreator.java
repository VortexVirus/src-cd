package net.minecraft.client.renderer.texture;

public interface IIconCreator
{
    void registerSprites(TextureMap iconRegistry);
}
