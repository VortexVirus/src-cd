package net.minecraft.client.resources;

public interface IResourceManagerReloadListener
{
    void onResourceManagerReload(IResourceManager resourceManager);
}
