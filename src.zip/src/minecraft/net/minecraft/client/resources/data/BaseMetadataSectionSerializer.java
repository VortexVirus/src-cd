package net.minecraft.client.resources.data;

public abstract class BaseMetadataSectionSerializer<T extends IMetadataSection> implements IMetadataSectionSerializer<T>
{
}
