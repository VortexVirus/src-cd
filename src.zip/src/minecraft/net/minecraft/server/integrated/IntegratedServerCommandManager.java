package net.minecraft.server.integrated;

import net.minecraft.command.ServerCommandManager;

public class IntegratedServerCommandManager extends ServerCommandManager
{
}
