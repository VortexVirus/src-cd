package net.minecraft.src;

public class WorldServerMultiOF
{
}
