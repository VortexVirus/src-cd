package net.minecraft.src;

import net.minecraft.client.settings.GameSettings;

public interface IOptionControl
{
    GameSettings.Options getOption();
}
