package net.minecraft.src;

public class GlBlendState
{
    public boolean enabled;
    public int srcFactor;
    public int dstFactor;
}
