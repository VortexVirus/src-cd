package net.minecraft.src;

public interface IFileUploadListener
{
    void fileUploadFinished(String var1, byte[] var2, Throwable var3);
}
