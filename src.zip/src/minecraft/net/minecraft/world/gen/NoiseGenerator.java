package net.minecraft.world.gen;

public abstract class NoiseGenerator
{
}
