package net.minecraft.util;

public class MinecraftError extends Error
{
}
