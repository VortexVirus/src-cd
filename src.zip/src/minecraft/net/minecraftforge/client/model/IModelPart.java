package net.minecraftforge.client.model;

public interface IModelPart
{
}
