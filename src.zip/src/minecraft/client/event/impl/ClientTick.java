package client.event.impl;

import client.event.Event;

public class ClientTick extends Event {

}
