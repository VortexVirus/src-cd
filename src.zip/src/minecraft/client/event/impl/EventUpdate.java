package client.event.impl;

import client.event.Event;

public class EventUpdate extends Event {

}
