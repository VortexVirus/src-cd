package client.gui.clickgui;

public class ModsSettings {

	public ModsSettings() {
		// TODO Auto-generated constructor stub
	}

}
